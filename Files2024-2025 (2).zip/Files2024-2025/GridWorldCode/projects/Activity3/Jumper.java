import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;

public class Jumper extends Bug {
    private int moveLimit; // Determines how far it moves before changing direction
    private int movesSinceTurn; // Tracks moves in the same direction 
    private int turnMoves;

    // Default constructor: Blue color, move limit of 5
    public Jumper() {
        setColor(Color.BLUE);
        this.moveLimit = 5;
        this.movesSinceTurn = 0;
        this.turnMoves = 0;
    }

    // Constructor with custom move limit
    public Jumper(int moveLimit) {
        setColor(Color.BLUE);
        this.moveLimit = moveLimit;
        this.movesSinceTurn = 0;
        this.turnMoves = 0;
    }

    // Checks if a move is possible two spaces away
    public boolean canMove() {
        Grid<Actor> gr = getGrid();
        if (gr == null) return false;

        Location next = getLocation().getAdjacentLocation(getDirection());
        Location skipNext = next.getAdjacentLocation(getDirection());
        if (gr.isValid(skipNext))  
        {
            Actor neighbor = gr.get(skipNext);
            return (neighbor == null || (neighbor instanceof Flower && !(neighbor instanceof Blossom)));
        }
        else return false;
    }

    public void move() 
    {
        Grid<Actor> gr = getGrid();
        if (gr == null) return;

        Location currentLoc = getLocation();
        Location jumpLoc = currentLoc.getAdjacentLocation(getDirection()).getAdjacentLocation(getDirection());

        if (canMove()) {
            moveTo(jumpLoc); // Jump forward two spaces
            turnMoves = 0;
            movesSinceTurn++; // Increment move counter
            Blossom blossom = new Blossom((int)(Math.random()*11) + 5); // Random lifetime between 5-15
            blossom.putSelfInGrid(gr, currentLoc);
        }
         else {
                Location oneStepLoc = currentLoc.getAdjacentLocation(getDirection());
                if(turnMoves >= 8 && gr.isValid(oneStepLoc) && (gr.get(oneStepLoc) == null 
                || (gr.get(oneStepLoc) instanceof Flower && !(gr.get(oneStepLoc) instanceof Blossom))))
                {
                    moveTo(oneStepLoc);
                    turnMoves = 0;
                    movesSinceTurn++;
                    Blossom blossom = new Blossom((int)(Math.random()*11) + 5); // Random lifetime b
                    blossom.putSelfInGrid(gr, currentLoc);
                }
                else 
                {
                    setDirection(getDirection() + Location.HALF_RIGHT);
                    movesSinceTurn = 0;
                    turnMoves++;
                }
         }
        
    }
    public void act() {
        Grid<Actor> gr = getGrid();
        if (gr == null) return;

        // Move the Jumpe
        if(movesSinceTurn < moveLimit)
            move();

        // Change direction after reaching move limit
        else  {
            setDirection(getDirection() + 45); // Turn 90 degrees after moveLimit is reached
            movesSinceTurn = 0;
        }
    }
}

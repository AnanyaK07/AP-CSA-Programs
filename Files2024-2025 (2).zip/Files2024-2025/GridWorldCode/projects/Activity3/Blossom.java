import info.gridworld.actor.Flower;
import java.awt.Color;

public class Blossom extends Flower {
    private int lifetime;

    // No-args constructor (sets default lifetime to 10)
    public Blossom() {
        super(Color.GREEN); // Start as green
        this.lifetime = 10;
    }

    // Constructor with specified lifetime
    public Blossom(int lifetime) {
        super(Color.GREEN);
        this.lifetime = lifetime;
    }

    // Act method to track lifetime
    public void act() {
        super.act(); // Call Flower's behavior (fading color)
        lifetime--;

        // Remove from grid when lifetime ends
        if (lifetime <= 0) {
            removeSelfFromGrid();
        }
    }
}


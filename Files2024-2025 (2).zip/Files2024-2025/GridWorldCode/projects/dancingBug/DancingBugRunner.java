import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import java.awt.Color;

/**
 * This class runs a world that contains box bugs. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public class DancingBugRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        int[] turns =
            {1, 0, 0, 0, 1, 0, 0, 3, 4,
                4, 0, 0, 1, 0, 3, 2, 0, 7,
                0, 0, 0, 3, 2, 1 }; 
        DancingBug alice = new DancingBug(turns);
        world.add(new Location(4, 1), alice);
        world.show();
    }
}
import info.gridworld.actor.Bug;

public class DancingBug extends Bug {
    private int[] turns; // Array storing how many times to turn at each step
    private int stepIndex;  // Keeps track of the current turn index in the array

    public DancingBug(int[] turnsln) {
        stepIndex = 0;
        turns = turnsln;
    }

    public void act() {
        if (stepIndex < turns.length) {
            // Turn the bug according to the array value
            for (int i = 0; i < turns[stepIndex]; i++) {
                turn();
            }
            if(canMove())
                move();
            stepIndex++;
        }

        // Move forward if possible
        else {
            stepIndex = 0;
        }
    }
}

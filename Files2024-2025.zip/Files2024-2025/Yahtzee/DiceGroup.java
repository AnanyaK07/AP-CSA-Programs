/**
 * DiceGroup class
 * This program uses the Dice class and implements it so all
 * five dice are rolled and printed.
 * 
 * @author 		Ananya Kotla
 * @since 		October 25, 2024
 */


public class DiceGroup {
	
	private Dice [] die;	// the array of dice
	
	private final int NUM_DICE = 5;	// number of dice
	
	// Create the seven different line images of a die
	private String [] line = {	" _______ ",
								"|       |",
								"| O   O |",
								"|   O   |",
								"|     O |",
								"| O     |",
								"|_______|" };
	
	/*	you complete */
	
	/**
	 * No-args constructor: initializes all field vars
	 */
	public DiceGroup() 
	{ 
		die = new Dice[NUM_DICE];
		for(int a = 0; a < NUM_DICE; a++)
		{
			die[a] = new Dice();
		}
	}
	
	/**
	 * Rolls all the dice
	 */
	public void rollDice() 
	{ 
		for(int b = 0; b < NUM_DICE ; b++)
		{
			die[b].roll();
		}
	}
	
	/**	Hold the dice in the rawHold and roll the rest.
	 *	For example: If rawHold is "421", then hold die 1, 2, and 4, and
	 *	roll 3 and 5.
	 *	@param rawHold		the string of dice to hold
	 *
	 *	you complete
	 */
	public void rollDice(String rawHold) 
	{ 
		boolean roll = true;
		int[] hold = new int[rawHold.length()];
		for(int c = 0; c < rawHold.length(); c++)
		{
			hold[c] = Integer.parseInt(rawHold.substring(c, c + 1));
		}
		for(int d = 0; d < NUM_DICE ; d++)
		{
			for(int e = 0; e < hold.length; e++)
			{
				if(hold[e] == d + 1)
				{
					roll = false;
				}
			}
			if(roll)
			{
				die[d].roll();
			}
			roll = true;
		}
		
	}
	
	
	/**	getters - you complete */
	
	/**	@return the total value of the DiceGroup - you complete */
	public int getTotal() 
	{ 
		int total = 0;
		for(int g = 0; g < 	NUM_DICE ; g++)
		{
			total = total + die[g].getValue();
		}
		return total;
	}

	/**
	 * @param  dieNum	resembles one out of the five dice	
	 * @return die	    a certain die's value
	 */
	public int getOneValue(int dieNum)
	{
		return die[dieNum - 1].getValue();
	}
	
	/**
	 *  Prints out the images of the dice
	 */
	public void printDice() {
		printDiceHeaders();
		for (int i = 0; i < 6; i++) {
			System.out.print(" ");
			for (int j = 0; j < die.length; j++) {
				printDiceLine(die[j].getValue() + 6 * i);
				System.out.print("     ");
			}
			System.out.println();
		}
		System.out.println();
	}
	
	/**
	 *  Prints the first line of the dice.
	 */
	private void printDiceHeaders() {
		System.out.println();
		for (int i = 1; i < 6; i++) {
			System.out.printf("   # %d        ", i);
		}
		System.out.println();
	}
	
	/**
	 *  Prints one line of the ASCII image of the dice.
	 *
	 *  @param value The index into the ASCII image of the dice.
	 */
	private void printDiceLine(int value) {
		System.out.print(line[getDiceLine(value)]);
	}
	
	/**
	 *  Gets the index number into the ASCII image of the dice.
	 *
	 *  @param value The index into the ASCII image of the dice.
	 */
	private int getDiceLine(int value) {
		if (value < 7) return 0;
		if (value < 14) return 1;
		switch (value) {
			case 20: case 22: case 25:
				return 1;
			case 16: case 17: case 18: case 24: case 28: case 29: case 30:
				return 2;
			case 19: case 21: case 23:
				return 3;
			case 14: case 15:
				return 4;
			case 26: case 27:
				return 5;
			default:	// value > 30
				return 6;
		}
	}
}

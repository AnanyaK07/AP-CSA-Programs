public class test
{
	public static void main(String[] args)
	{
		for(int x = 0; x < 5; x++);
		{
			System.out.println("hi");
		}
	}
}

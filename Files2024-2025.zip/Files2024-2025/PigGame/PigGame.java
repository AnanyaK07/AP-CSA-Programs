/** PigGame class
 *	The game of Pig.
 *	The Pig Game is dice game. In this situation its computer vs human.
 *  Each take turns rollling a die and the first to score 100 points wins. 
 *  A player can either ROLL (if the die is 2 through 6, points are added
 *  to turn total, player's turn continues; if die is 1: player loses turn
 *  and nothing is added to final score) or HOLD (turn total is added to 
 *  player's score, turn goes to other player).
 *	@author	Ananya Kotla
 *	@since	September 14, 2024
 */
import java.util.Scanner;
public class PigGame 
{
	private int compFinalScore;		// Total score of comuputer
	private int userFinalScore;		// Total score of user
	private int userTurnScore;		// Turn score of computer
	private	int compTurnScore;		// Turn score of user
	private boolean userTurn;		// if true it's user's turn
									// if false, it's computer's turn
	private String continueNext;  	// whenever prog asks for user input,
									// output is saved in this String
	
	/**	Constructor of the the class (no-args)
		Initializes all field variables
	*/								
	public PigGame()
	{
		compFinalScore = 0;
		userFinalScore = 0;
		userTurnScore = 0;
	    compTurnScore = 0;
	    userTurn = true;
		continueNext = new String("");
	}
	
	/**	Main method: creates object(instance of the class)
		Uses that object to call all the other methods of 
		this class.
	*/				
	public static void main(String[] args)
	{
		PigGame pg = new PigGame();
		pg.printIntroduction();
		pg.choose();
	}

	/**	Print the introduction to the game 	
	*/
	public void printIntroduction() 
	{
		System.out.println("\n\n");
		System.out.println("______ _         _____");
		System.out.println("| ___ (_)       |  __ \\");
		System.out.println("| |_/ /_  __ _  | |  \\/ __ _ _ __ ___   ___");
		System.out.println("|  __/| |/ _` | | | __ / _` | '_ ` _ \\ / _ \\");
		System.out.println("| |   | | (_| | | |_\\ \\ (_| | | | | | |  __/");
		System.out.println("\\_|   |_|\\__, |  \\____/\\__,_|_| |_| |_|\\___|");
		System.out.println("          __/ |");
		System.out.println("         |___/");
		System.out.println("\nThe Pig Game is human vs computer. Each takes a"
							+ " turn rolling a die and the first to score");
		System.out.println("100 points wins. A player can either ROLL or "
							+ "HOLD. A turn works this way:");
		System.out.println("\n\tROLL:\t2 through 6: add points to turn total, "
							+ "player's turn continues");
		System.out.println("\t\t1: player loses turn");
		System.out.println("\tHOLD:\tturn total is added to player's score, "
							+ "turn goes to other player");
		System.out.println("\n");
	}
	
	/**	This methods asks the user to either play the game
	    or to determine statistics when the computer is 
		playing. User will then choose either to play
		or stats using the Prompt class to scan the user's 
		input. Based on that, either the rolls method will run
		or the stats method.
	*/
	public void choose()
	{
		String chosen = new String("");
		Prompt p = new Prompt();
		chosen = p.getString("Play game or Statistics (p or s) -> "); 
		if(chosen.equalsIgnoreCase("p"))
		{
			rolls();
		}
		else if(chosen.equalsIgnoreCase("s"))
		{
			stats();
		}
	}

	/** Determines the stats if the computer were to roll a
	    certain number of times. Based on that it calculates the
		probability if a turn score were to be 0, 20, 21, 22, 23
		24, and 25
	 	It shows the probability in a table using printf to format it.
	*/
	public void stats()
	{
		int[] score = new int[1000000];
		double[] scoreStats = new double[7];
		int turns = 0;
		Dice d = new Dice();		
		int diceNum2 = 0;
		Prompt p = new Prompt();
		turns = p.getInt("\nNumber of turns (1000 - 1000000) -> ");
		if(turns <= 1000000 && turns >= 1000)
		{
			for(int a = 1; a <= turns; a++)
			{
				while(diceNum2 != 1 && compTurnScore <= 20)
				{
					diceNum2 = d.roll();
					if(diceNum2 != 1)
					{
						compTurnScore = compTurnScore + diceNum2;
					}
					if(diceNum2 == 1 || compTurnScore >= 20)
					{
						if(compTurnScore >= 20)
						{
							
							score[a-1] = compTurnScore;
						}
						else if( diceNum2 == 1)
						{
							score[a-1] = 0;
						}		
					}
				}
				diceNum2 = 0;
				compTurnScore = 0;
			}
			
			System.out.printf("\n%-8s%s","Score", "Estimated Probability");
			for(int b = 1; b <= turns; b++)
			{
				if(score[b-1] == 0)
				{
					scoreStats[0] = scoreStats[0] + 1;
				}
				else if(score[b-1] == 20)
				{
					scoreStats[1] = scoreStats[1] + 1;
				}
				else if(score[b-1] == 21)
				{
					scoreStats[2] = scoreStats[2] + 1;
				}
				else if(score[b-1] == 22)
				{
					scoreStats[3] = scoreStats[3] + 1;
				}
				else if(score[b-1] == 23)
				{
					scoreStats[4] = scoreStats[4] + 1;
				}
				else if(score[b-1] == 24)
				{
					scoreStats[5] = scoreStats[5] + 1;
				}
				else if(score[b-1] == 25)
				{
					scoreStats[6] = scoreStats[6] + 1;
				}
			}
			System.out.printf("\n%2d%13.5f", 0, scoreStats[0]/turns);
			System.out.printf("\n%2d%13.5f", 20, scoreStats[1]/turns);
			System.out.printf("\n%2d%13.5f", 21, scoreStats[2]/turns);
			System.out.printf("\n%2d%13.5f", 22, scoreStats[3]/turns);
			System.out.printf("\n%2d%13.5f", 23, scoreStats[4]/turns);
			System.out.printf("\n%2d%13.5f", 24, scoreStats[5]/turns);
			System.out.printf("\n%2d%13.5f", 25, scoreStats[6]/turns);
			System.out.println("\n");
		}	
	}

	/** Determines information for both when the user and computer rolls
	 	When the user or comp rolls it calls the dice class and returns the
		dice number. If the number is not 1, then the number is added
		to the turn score. If it is one, then the turn score is 0 and
		userTurn is changed to the other boolean value. If the user or
		comp holds, then the turn score is added to the final score and
		the hold method is called. Once one of them reaches 100, then the
		winner method is called.
	 */
	public void rolls()
	{
		Dice d = new Dice();		
		int diceNum = 0;

		while(compFinalScore < 100 && userFinalScore < 100)
		{
			if(userTurn == true)
			{
				System.out.println("\n**** USER Turn ***\n");
			}
			else if(userTurn == false)
			{
				System.out.println("\n**** COMPUTER'S Turn ***\n");
			}
			printScores();
			if(continueNext.equalsIgnoreCase("h"))
			{
				userTurn = false;
				System.out.println("\n");
			}
			while((userTurn == true && continueNext.equalsIgnoreCase("r")) 
				|| (userTurn == false && continueNext.equalsIgnoreCase("")))
			{
				diceNum = d.roll();
				if(userTurn == true)
				{
					System.out.println("\nYou ROLL");
				}
				else
				{
					System.out.println("\nComputer will ROLL");
				}
				d.printDice();
				if(diceNum != 1)
				{
					if(userTurn	== true)
					{
						userTurnScore = userTurnScore + diceNum;
					}
					else
					{
						compTurnScore = compTurnScore + diceNum;
					}
					System.out.println("");
				}
				else
				{
					if(userTurn == true)
					{
						System.out.println("\nYou LOSE your turn.");
						userTurnScore = 0;
						System.out.println("Your total score: " 
							+ userFinalScore + "\n");
						userTurn = false;
					
					}
					else
					{
						System.out.println("\nComputer LOSES turn.");
						compTurnScore = 0;
						System.out.println("Computer total score: " 
							+ compFinalScore + "\n");
						userTurn = true;
					}
					
				}
				holds();	
			}
		}
		winner();
	}

	/** This method is called when the user or comp holds
	 	The comp will only hold if it reaches a score of 
		20 or higher. The method all runs if the die is 1.
		It sets that turn to hold, so the while loop in the 
		rolls method will start from the top again. The user 
		holds by typing h.
	 */
	public void holds()
	{
		if(userTurnScore !=0 || compTurnScore !=0)
		{
			printScores();
					
			if((userTurn == false && compTurnScore >= 20) || 
				(userTurn == false && compTurnScore + compFinalScore >= 100))
			{
				continueNext = "h";
				System.out.println("Computer will HOLD");
				compFinalScore = compFinalScore + compTurnScore;
				System.out.println("Computer's total score: " + 
					compFinalScore + "\n");
				compTurnScore = 0;
				userTurn = true;
			}
			else if(continueNext.equalsIgnoreCase("h")&& userTurn == true)
			{
				System.out.println("\nYou HOLD");
				userFinalScore = userFinalScore + userTurnScore;
				System.out.println("Your total score: " + 
					userFinalScore + "\n");
				userTurnScore= 0;
				userTurn = false;
			}
		}
		else
		{	
			continueNext = "h";
		}
	}

	/**	Method that constantly shows their scores as well as 
	 	asks for user input during every turn (using Prompt class). 
	 	The user input is saved in a String (final var) and is used in 
	 	other methods.
	 */
	public void printScores()
	{
		Prompt p = new Prompt();
		if(userTurn == true)
		{
			System.out.printf("%-20s %d\n", "Your turn score:", userTurnScore);	
			System.out.printf("%-20s %d\n", "Your final score:", userFinalScore);
			continueNext = p.getString("\n(r)oll or (h)old -> ");
		}
		else

		{
			System.out.printf("%-20s %d\n", "Computer's turn score:", compTurnScore);	
			System.out.printf("%-20s %d\n", "Computer's final score:", compFinalScore);
			continueNext = p.getString("\nPress enter for computer turn -> ");	
		}
		
	}

	/** When either the comp or user wins, this method
	 *  is called. It prints either the statement if use
	 *  wins or if comp wins. Prints ending statement at 
	 *  the end.
	 */
	public void winner()
	{
		if(userFinalScore >= 100)
		{
			System.out.println("Congratulations!!! YOU WON!!!!");
		}
		else if(compFinalScore >= 100)
		{
			System.out.println("Computer WON!!!! Better Luck Next Time!");
		}
		System.out.println("\nThanks for playing the Pig Game!!!\n\n");
	}
}

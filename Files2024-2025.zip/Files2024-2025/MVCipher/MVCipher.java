// imports go here
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *	MVCipher - This program will use a variation of Caesar Cipher.
 *  It was called a shift  cipher because letters of the original message 
 *  are replaced by letters a certain number of letters up or down the alphabet.
 *  The MV Cipher uses a series of Caesar ciphers based on the letters of
 *	a keyword. It will either encrypt (shift up) or decrypt (shift down) 
 *  the message. The encrypted or decrypted message will be stored in a
 *  txt file. The file the it will be encrypting or decrypting is Macbeth.txt.
 *	Requires Prompt and FileUtils classes.
 *	
 *	@author		Ananya Kotla
 *	@since		September 20, 2024
 */
public class MVCipher 
{
	
	// fields go here
	private String key;		// The keyword that will be used to shift up
							// or shift down the message.
	private boolean encryptYes;		// checks if the user selects encrypt or
									// decrypt
		
	/** Constructor 
	 * Initializes field variables.
	 */
	public MVCipher() 
	{ 
		key = new String("");
		encryptYes = false;
	}
	
	/**	Main Method
	 * 	Creates an instance of the class, uses it to run the 
	 *  other methods
	 */
	public static void main(String[] args) {
		MVCipher mvc = new MVCipher();
		mvc.run();
	}
	
	/**
	 *	This method asks the user to input a word used as the keyword,
	 *  using the prompt class. It then asks the user to either select
	 *  encrypt or to decrypt. Then it asks for the file name used for
	 *  encrypting or decrypting. It checks if that file exists using
	 *  the FileUtils class. The asks for the name of the file where
	 *  the encrypted/decrypted code will be. It creates the file
	 *  using PrintWriter and the FileUtils class. It then calls the 
	 *  method where the encrypting/decrypting. It will print the final
	 *  message at the end and close the printwriter.
	 */
	public void run() 
	{
		System.out.println("\n Welcome to the MV Cipher machine!\n");
		
		/* Prompt for a key and change to uppercase
		   Do not let the key contain anything but alpha
		   Use the Prompt class to get user input */
		Prompt p = new Prompt();
		boolean again = true;
		boolean notALetter = false;
		int checkValue = 0;
		while(again == true)
		{
			key = p.getString("Please input a word to use as key "
				+ "(letters only)");
			for(int a = 0; a < key.length(); a++)
			{
				checkValue = key.charAt(a);
				if(!((checkValue >= 'A' && checkValue <= 'Z') || 
					(checkValue >= 'a' && checkValue <= 'z')))
				{
					notALetter = true;
				}
			}
			if(key.length() < 3 || notALetter == true)
			{
				System.out.println("ERROR: Key must be all letters and "
					+ "at least 3 characters long");
			}
			else
			{
				key = key.toUpperCase();
				again = false;
			}
			notALetter = false;
		}
		
		/* Prompt for encrypt or decrypt */
		int getNum = 0;
		while(!(getNum == 1 || getNum == 2))
		{
			getNum = p.getInt("\nEncrypt or decrypt? (1, 2)");
			if(getNum == 1)
			{
				encryptYes = true;
			}
			else if(getNum == 2)
			{
				encryptYes = false;
			}
		}
			
		/* Prompt for an input file name */
		FileUtils fu = new FileUtils();
		String chosenFile = new String("");
		if(encryptYes == true)
		{
			chosenFile = p.getString("\nName of file to encrypt");
		}
		else
		{
			chosenFile = p.getString("\nName of file to decrypt");
		}
		Scanner readFile = fu.openToRead(chosenFile);
	
		/* Prompt for an output file name */
		String outFileName = p.getString("Name of output file");
		PrintWriter outFile = fu.openToWrite(outFileName);
		
		/* Read input file, encrypt or decrypt, and print to output file */
		createOutFile(readFile, outFile);
		System.out.println();
		if(encryptYes == true)
		{
			System.out.println("The encrypted file " + outFileName + 
				" has been created using the keyword -> " + key + "\n");
		}
		else
		{
			System.out.println("The decrypted file " + outFileName + 
				" has been created using the keyword -> " + key + "\n");
		}
		
		/* Don't forget to close your output file */
		outFile.close();
	}

	// other methods go here
	/**
	 * This method will read each character of Macbeth.txt and will
	 * call other methods to encrypt/decrypt if its a lowercase of 
	 * uppercase letter. If not, it will be printed as it is. It will
	 * then add each character to a string where the new encypted line is.
	 * That line will be printed onto the output file.
	 * @param readFile		the Scanner that will be reading Macbeth.txt
	 * @param outFile		the printWriter that will writing the file
	 * 						where the encrypted/decrypted code will be
	 */
	public void createOutFile(Scanner readFile, PrintWriter outFile)
	{
		String readLine = new String("");
		int asciiOfKey = 0;
		int asciiOfLine = 0;
		int numOfKey = 0;
		int diffOfBoth = 0;
		int goBack = 0;
		String newLine = new String("");
		char newLetter = ' ';
		while (readFile.hasNext()) 
         {
			readLine = readFile.nextLine();
			for(int y = 0; y < readLine.length(); y++)
			{
				if((readLine.charAt(y) >= 'A' && readLine.charAt(y) <= 'Z') 
				|| (readLine.charAt(y) >= 'a' &&  readLine.charAt(y) <= 'z'))
				{
					asciiOfLine = readLine.charAt(y);
					if(asciiOfLine > 'Z')
					{
						newLetter = fixLowerCase(asciiOfLine, asciiOfKey, 
								numOfKey, diffOfBoth, goBack, newLetter);
					}
					else
					{
						newLetter = fixUpperCase(asciiOfLine, asciiOfKey, 
								numOfKey, diffOfBoth, goBack, newLetter);
					}
					newLine = newLine + newLetter;
					if(numOfKey < key.length() - 1)
					{
						numOfKey++;
					}
					else
					{
						numOfKey = 0;
					}
				}
				else
				{
					newLine = newLine + readLine.charAt(y);
				}
			}
			outFile.println(newLine);
			newLine = "";
		 }
	}

	/**
	 * Encrypts/Decrypts each UpperCase letter part of Macbeth.txt 
	 * using the keycode and returns the encrypted/decrypted letter.
	 * @param asciiOfLine		the ascii num of the Capital Letter
	 * @param asciiOfKey		the ascii num of the keycode letter
	 * @param numOfKey			the index value of the keycode that it is on
	 * @param diffOfBoth		the num that the letter has to be shifted
	 * @param goBack			the num that the letter is shifted to z or
	 * 							shifted back to a
	 * @param newLetter 		the new decrypted/encrypted letter;
	 * @return 					the new decrypted/encrypted capital letter;
	 */
	public char fixUpperCase (int asciiOfLine, int asciiOfKey, int numOfKey, 
							  int diffOfBoth, int goBack, char newLetter)
	{
		asciiOfKey = key.charAt(numOfKey);
		diffOfBoth = asciiOfKey - ('A'- 1);
		if(encryptYes == false)
		{
			diffOfBoth = -1 * (diffOfBoth);
		}
		if(asciiOfLine <= 'Z' && (asciiOfLine + diffOfBoth > 'Z' ||
		   asciiOfLine + diffOfBoth < 'A'))
		{
			if(encryptYes == true)
			{
				goBack = 'Z' - asciiOfLine;
				newLetter = (char)(('A' - 1) + (diffOfBoth - goBack));
			}
			else
			{
				goBack = asciiOfLine - 'A';
				newLetter = (char)(('Z' + 1) + (diffOfBoth + goBack));
			}
		}
		else if((asciiOfLine <= 'Z' && asciiOfLine + diffOfBoth <= 'Z' && 
				 asciiOfLine + diffOfBoth >= 'A'))
		{
			newLetter = (char) (asciiOfLine + diffOfBoth);
			
		}
		return newLetter;
	}

	/**
	 * Encrypts/Decrypts each lowercase letter part of Macbeth.txt 
	 * using the keycode and returns the encrypted/decrypted letter.
	 * @param asciiOfLine		the ascii num of the lowercase Letter
	 * @param asciiOfKey		the ascii num of the keycode letter
	 * @param numOfKey			the index value of the keycode that it is on
	 * @param diffOfBoth		the num that the letter has to be shifted
	 * @param goBack			the num that the letter is shifted to z or
	 * 							shifted back to a
	 * @param newLetter 		the new decrypted/encrypted letter;
	 * @return 					the new decrypted/encrypted lowercase letter;
	 */
	public char fixLowerCase(int asciiOfLine, int asciiOfKey, int numOfKey, 
							 int diffOfBoth, int goBack, char newLetter)
	{
		asciiOfKey = key.charAt(numOfKey);
		asciiOfKey = asciiOfKey + 32;
		diffOfBoth = asciiOfKey - ('a' - 1);
		if(encryptYes == false)
		{
			diffOfBoth = -1 * (diffOfBoth);
		}
		if((asciiOfLine >= 'a' && asciiOfLine + diffOfBoth <= 'z' && 
			asciiOfLine + diffOfBoth >= 'a'))
		{
			newLetter = (char) (asciiOfLine + diffOfBoth);
		}
		else if(asciiOfLine >= 'a' && (asciiOfLine + diffOfBoth > 'z' || 
			asciiOfLine + diffOfBoth < 'a'))
		{
			if(encryptYes == true)
			{
				goBack = 'z' - asciiOfLine;
				newLetter = (char)(('a' - 1) + (diffOfBoth - goBack));
			}
			else
			{
				goBack = asciiOfLine - 'a';
				newLetter = (char)(('z' + 1) + (diffOfBoth + goBack));
			}
		}
		return newLetter;
	}
}

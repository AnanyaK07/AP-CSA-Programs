public class Coyote extends Critter
{
	private int steps;
	private static final int THRESHOLD = 5;
	
	public Coyote()
    {
        setColor(null);
        steps = 0;
        setDirection((int)(Math.random()*8 + 1) * 45));
    }
    
    public void makeMove(Location loc)
    {
        if (loc == null)
            removeSelfFromGrid();
        else
            moveTo(loc);
    }
    
    public ArrayList<Location> getMoveLocations()
    {
		Location next = getLocation().getAdjacentLocation(getDirection());
		ArrayList<Location> loc = new ArrayList<Location>();
		loc.add(next);
        return loc;
    }
}

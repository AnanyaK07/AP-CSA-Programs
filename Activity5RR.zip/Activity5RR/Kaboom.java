import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
/**
 * 
 * 
 *
 */

public class Kaboom extends Actor
{
	private int steps;
	private static final int THRESHOLD = 3;
	
	public Kaboom()
    {
        setColor(null);
        steps = THRESHOLD;
    }
    
    public void act()
    {
		steps--;
		if(steps == 0)
			removeSelfFromGrid();
    }
}


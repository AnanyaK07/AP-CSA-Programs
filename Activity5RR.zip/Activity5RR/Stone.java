import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
import info.gridworld.actor.Actor;

public class Stone extends Boulder
{
	private int steps;
	private static final int THRESHOLD = 3;
	
	public Stone()
    {
        setColor(null);
        steps = (int)(Math.random()*199 + 1);
    }
    
    public Stone(int stepsLn)
    {
        setColor(null);
        steps = stepsLn;
    }
    
    
    public void act()
    {
		steps--;
		if(steps < THRESHOLD)
			setColor(Color.GREEN);
		if(steps == 0)
		{
			Grid<Actor> gr = getGrid();
				if (gr == null)	return;
			Location loc = getLocation();
			removeSelfFromGrid();
			Boulder boulder = new Boulder();
			boulder.putSelfInGrid(gr, loc);
		}
		
    }
}


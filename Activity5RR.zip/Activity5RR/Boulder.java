import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
/**
 * 
 * 
 *
 */

public class Boulder extends Actor
{
	private int steps;
	private static final int THRESHOLD = 3;
	
	public Boulder()
    {
        setColor(null);
        steps = (int)(Math.random()*199 + 1);
    }
    
    public Boulder(int stepsLn)
    {
        setColor(null);
        steps = stepsLn;
    }
    
    
    public void act()
    {
		steps--;
		if(steps < THRESHOLD)
			setColor(Color.RED);
		if(steps == 0)
		{
			Grid<Actor> gr = getGrid();
				if (gr == null)	return;
			Location loc = getLocation();
			removeSelfFromGrid();
			Kaboom kaboom = new Kaboom();
			kaboom.putSelfInGrid(gr, loc);
		}
		
    }
}

